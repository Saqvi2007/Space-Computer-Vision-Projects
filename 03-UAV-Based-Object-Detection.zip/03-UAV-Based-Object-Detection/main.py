import cv2
import numpy as np
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
dataset_dir = os.path.join(BASE_DIR, "dataset")

# 1. Automatic Search for frame_00 in dataset folder
possible_files = ["frame_00.jpg", "frame_00.jpeg", "frame_00.png", "frame_00"]
input_path = None

for filename in possible_files:
    temp_path = os.path.join(dataset_dir, filename)
    if os.path.exists(temp_path):
        input_path = temp_path
        break

# Fallback: Check Project 1 dataset directly if missing here
if input_path is None:
    fallback_path = os.path.join(BASE_DIR, "..", "01-Rover-Vision-Navigation", "dataset", "frame_00.jpg")
    if os.path.exists(fallback_path):
        input_path = fallback_path

output_dir = os.path.join(BASE_DIR, "outputs")
output_path = os.path.join(output_dir, "uav_detected_objects.png")

img = cv2.imread(input_path) if input_path else None

if img is None:
    print("--------------------------------------------------")
    print(f"ERROR: Image file not accessible in {dataset_dir}")
    print("Please re-copy frame_00.jpg into dataset folder.")
    print("--------------------------------------------------")
else:
    print(f"Loaded image successfully from: {input_path}")
    
    # 2. Convert to Grayscale & Apply CLAHE Enhancement
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)

    # 3. Thresholding for Aerial Objects
    _, thresh = cv2.threshold(enhanced, 180, 255, cv2.THRESH_BINARY)

    # 4. Find Ground Object Contours
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    object_count = 0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > 80:  # Spatial filter
            object_count += 1
            x, y, w, h = cv2.boundingRect(cnt)
            # Green Bounding Box for UAV Target
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(img, f"Target #{object_count}", (x, y - 5), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)

    os.makedirs(output_dir, exist_ok=True)
    cv2.imwrite(output_path, img)

    print("--------------------------------------------------")
    print("SUCCESS: UAV-Based Object Detection Complete!")
    print(f"Total Aerial Targets Detected: {object_count}")
    print(f"Output saved at: {output_path}")
    print("--------------------------------------------------")