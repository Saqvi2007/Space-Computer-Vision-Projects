# Project 3: UAV-Based Object Detection

## Objective
Detect ground features and surface target structures from aerial drone/UAV planetary imagery using CLAHE contrast enhancement and spatial contour bounding.

## Methodology
1. CLAHE Contrast Normalization for aerial lighting variation.
2. Binary Intensity Segmentation.
3. Morphological filtering and ground object contour detection.
4. Spatial target labeling with bounding indicators.

## Tools & Libraries
- Python 3, OpenCV, NumPy

## Results
- SUCCESS: UAV-Based Object Detection Complete!
Total Aerial Targets Detected: 113
Output saved at: C:\Users\saqvi\OneDrive\Desktop\Computer_Vision_Projects\03-UAV-Based-Object-Detection\outputs\uav_detected_objects.png