import cv2
import numpy as np
import os

# Get absolute path of the directory where main.py is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Construct full paths to input images and output destination
img1_path = os.path.join(BASE_DIR, "dataset", "frame_00.jpg")
img2_path = os.path.join(BASE_DIR, "dataset", "frame_01.jpg")
output_dir = os.path.join(BASE_DIR, "outputs")
output_path = os.path.join(output_dir, "matched_craters.png")

# Read images in grayscale
img1 = cv2.imread(img1_path, cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread(img2_path, cv2.IMREAD_GRAYSCALE)

if img1 is None or img2 is None:
    print("--------------------------------------------------")
    print("ERROR: Image files could not be loaded!")
    print(f"Checking Path 1: {img1_path}")
    print(f"Checking Path 2: {img2_path}")
    print("Please verify that frame_00.jpg and frame_01.jpg exist inside the 'dataset' folder.")
    print("--------------------------------------------------")
else:
    # 1. Initialize ORB Detector
    orb = cv2.ORB_create(nfeatures=1000)

    # 2. Extract Keypoints & Descriptors
    kp1, des1 = orb.detectAndCompute(img1, None)
    kp2, des2 = orb.detectAndCompute(img2, None)

    # 3. Match Features using Brute-Force Matcher
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = bf.match(des1, des2)
    matches = sorted(matches, key=lambda x: x.distance)

    # 4. Draw top 50 matches
    result_img = cv2.drawMatches(
        img1, kp1, img2, kp2, matches[:50], None, 
        flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
    )

    # 5. Save output image
    os.makedirs(output_dir, exist_ok=True)
    cv2.imwrite(output_path, result_img)
    
    print("--------------------------------------------------")
    print("SUCCESS: Feature matching executed successfully!")
    print(f"Keypoints detected in Frame 00: {len(kp1)}")
    print(f"Keypoints detected in Frame 01: {len(kp2)}")
    print(f"Total Matches Found: {len(matches)}")
    print(f"Output visualization saved at: {output_path}")
    print("--------------------------------------------------")