# Project 5: Real-Time Object Detection for Robotic Applications

## Objective
Implement multi-target classification and tracking for autonomous planetary rovers to identify surface landmarks (craters, boulders, soil sampling sites).

## Methodology
1. Gaussian Filtering for high-frequency noise mitigation.
2. Adaptive Gaussian Binarization.
3. Spatial Contour Analysis & Aspect Ratio classification.
4. Real-time visual overlay tagging with dynamic diagnostic metadata.

## Tools & Libraries
- Python 3, OpenCV, NumPy

## Results
- Generated multi-target identification map saved in `outputs/robotic_detection_result.png`.