import cv2
import numpy as np
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
dataset_dir = os.path.join(BASE_DIR, "dataset")

# Auto-detect image file
possible_files = ["frame_00.jpg", "frame_00.jpeg", "frame_00.png", "frame_00"]
input_path = None

for filename in possible_files:
    temp_path = os.path.join(dataset_dir, filename)
    if os.path.exists(temp_path):
        input_path = temp_path
        break

if input_path is None:
    fallback_path = os.path.join(BASE_DIR, "..", "01-Rover-Vision-Navigation", "dataset", "frame_00.jpg")
    if os.path.exists(fallback_path):
        input_path = fallback_path

output_dir = os.path.join(BASE_DIR, "outputs")
output_path = os.path.join(output_dir, "robotic_detection_result.png")

img = cv2.imread(input_path) if input_path else None

if img is None:
    print("--------------------------------------------------")
    print(f"ERROR: Image file not accessible in {dataset_dir}")
    print("--------------------------------------------------")
else:
    print(f"Loaded image successfully from: {input_path}")

    # 1. Convert to Grayscale & Apply Morphological Smoothing
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)

    # 2. Adaptive Binary Thresholding for Target Separation
    thresh = cv2.adaptiveThreshold(
        blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV, 13, 2
    )

    # 3. Contour Detection for Robotic Target Tracking
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    detected_targets = 0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > 100:  # Spatial filter for robotic target scale
            detected_targets += 1
            x, y, w, h = cv2.boundingRect(cnt)

            # Classify Target based on Aspect Ratio and Size
            aspect_ratio = float(w) / h
            if 0.8 <= aspect_ratio <= 1.2:
                label = "Target: Crater"
                color = (255, 0, 0)  # BLUE for Craters
            else:
                label = "Target: Rock"
                color = (0, 255, 255)  # YELLOW for Rocks

            # Draw Bounding Box & Label
            cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
            cv2.putText(img, f"{label} #{detected_targets}", (x, y - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)

    # Add System Diagnostics Overlay
    cv2.putText(img, f"Robotic Vision Active | Total Targets: {detected_targets}", 
                (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    os.makedirs(output_dir, exist_ok=True)
    cv2.imwrite(output_path, img)

    print("--------------------------------------------------")
    print("SUCCESS: Real-Time Robotic Object Detection Complete!")
    print(f"Total Robotic Targets Identified: {detected_targets}")
    print(f"Output saved at: {output_path}")
    print("--------------------------------------------------")