import cv2
import numpy as np
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
dataset_dir = os.path.join(BASE_DIR, "dataset")

# Auto-search image file
possible_files = ["frame_00.jpg", "frame_00.jpeg", "frame_00.png", "frame_00"]
input_path = None

for filename in possible_files:
    temp_path = os.path.join(dataset_dir, filename)
    if os.path.exists(temp_path):
        input_path = temp_path
        break

if input_path is None:
    fallback_path = os.path.join(BASE_DIR, "..", "01-Rover-Vision-Navigation", "dataset", "frame_00.jpg")
    if os.path.exists(fallback_path):
        input_path = fallback_path

output_dir = os.path.join(BASE_DIR, "outputs")
output_path = os.path.join(output_dir, "detected_lane_path.png")

img = cv2.imread(input_path) if input_path else None

if img is None:
    print("--------------------------------------------------")
    print(f"ERROR: Image file not found in {dataset_dir}")
    print("--------------------------------------------------")
else:
    print(f"Loaded image successfully from: {input_path}")

    # 1. Grayscale Conversion
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 2. Gaussian Smoothing & Edge Extraction
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, 40, 120)

    # 3. Simple Contour Tracking for Surface Path Boundaries
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    line_count = 0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > 15:  # Filter out small noise
            line_count += 1
            # Draw CYAN boundary lines for tracked path
            cv2.drawContours(img, [cnt], -1, (255, 255, 0), 2)

    # Safe Corridor Marking Label
    cv2.putText(img, "Path Status: CLEAR", (20, 40), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    os.makedirs(output_dir, exist_ok=True)
    cv2.imwrite(output_path, img)

    print("--------------------------------------------------")
    print("SUCCESS: Road Lane & Path Detection Complete!")
    print(f"Total Path Segment Features Tracked: {line_count}")
    print(f"Output saved at: {output_path}")
    print("--------------------------------------------------")