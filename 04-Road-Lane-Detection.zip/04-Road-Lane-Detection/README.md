# Project 4: Road Lane Detection and Departure Warning

## Objective
Detect surface tracks, path boundaries, and navigation corridors for autonomous terrain rovers using Canny Edge Detection and Hough Line Transforms.

## Methodology
1. Gaussian Blurring for high-frequency noise removal.
2. Canny Edge Extraction.
3. Polygonal Region of Interest (ROI) masking.
4. Probabilistic Hough Line Transformation for linear boundary tracking.

## Tools & Libraries
- Python 3, OpenCV, NumPy

## Results
- SUCCESS: Road Lane & Path Detection Complete!
Total Path Segment Features Tracked: 289
Output saved at: C:\Users\saqvi\OneDrive\Desktop\Computer_Vision_Projects\04-Road-Lane-Detection\outputs\detected_lane_path.png