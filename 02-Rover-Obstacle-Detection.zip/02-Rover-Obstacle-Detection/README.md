# Project 2: Autonomous Robot Obstacle Detection and Avoidance

## Objective
Detect surface hazards, rocks, and crater depressions in rover terrain using adaptive thresholding and contour-based bounding box generation.

## Methodology
1. Gaussian Smoothing for noise reduction.
2. Adaptive Gaussian Binarization.
3. Morphological filtering to eliminate small artifacts.
4. Contour area evaluation & spatial bounding box visualization.

## Tools & Libraries
- Python 3, OpenCV, NumPy

## Results
SUCCESS: Autonomous Obstacle Detection Complete!
Total Hazards/Obstacles Detected: 78
Output saved at: C:\Users\saqvi\OneDrive\Desktop\Computer_Vision_Projects\02-Rover-Obstacle-Detection\outputs\detected_obstacles.png