import cv2
import numpy as np
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
input_path = os.path.join(BASE_DIR, "dataset", "frame_00.jpg")
output_dir = os.path.join(BASE_DIR, "outputs")
output_path = os.path.join(output_dir, "detected_obstacles.png")

img = cv2.imread(input_path, cv2.IMREAD_GRAYSCALE)

if img is None:
    print("--------------------------------------------------")
    print(f"ERROR: Image not found at {input_path}")
    print("--------------------------------------------------")
else:
    # 1. Noise reduction using Gaussian Blur
    blurred = cv2.GaussianBlur(img, (5, 5), 0)

    # 2. Adaptive Thresholding to separate hazards from terrain
    thresh = cv2.adaptiveThreshold(
        blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
        cv2.THRESH_BINARY_INV, 11, 2
    )

    # 3. Clean noise using morphological operation
    kernel = np.ones((3, 3), np.uint8)
    cleaned = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)

    # 4. Find contours of detected obstacles
    contours, _ = cv2.findContours(cleaned, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    output_img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

    obstacle_count = 0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > 120:  # Filter out minor surface dots
            obstacle_count += 1
            x, y, w, h = cv2.boundingRect(cnt)
            # Red Bounding Box draw karna
            cv2.rectangle(output_img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.putText(output_img, "Hazard", (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)

    os.makedirs(output_dir, exist_ok=True)
    cv2.imwrite(output_path, output_img)

    print("--------------------------------------------------")
    print("SUCCESS: Autonomous Obstacle Detection Complete!")
    print(f"Total Hazards/Obstacles Detected: {obstacle_count}")
    print(f"Output saved at: {output_path}")
    print("--------------------------------------------------")